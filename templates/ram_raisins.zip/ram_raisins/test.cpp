#include <iostream>

using namespace std;

int main() {
	int a[3] = {1, 2, 3};
	cout << a[1] << endl;
	cout << a[-1] << endl;
	cout << a[-2] << endl;
	cout << a[-3] << endl;
	return 0;
}
